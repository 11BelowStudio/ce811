TO RUN THE BOT

It's in the MyAgent class within agent/MyAgent.py

If you want to try training a better agent, please use Assignment2-HopefullyLessDepressing.ipynb

And if you'd rather see a good agent, but made for a lab session instead of for the assignment,
and actually scores better than single-digit scores,
please go to botcreation/from_lab_7_and_actually_better_than_this/MyAgent.py

I would have used that as my final bot submission for this assignment, but seeing as that was
technically lab work instead of explicitly assignment work, I'm not sure if I'd be allowed to do that.
(However, if I was allowed to do that, I guess you could consider this as me doing that in hindsight,
if this counts towards anything)

I'm even more disappointed in this than you are, trust me.

